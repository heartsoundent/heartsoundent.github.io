# Heart Sound website — design draft

Single-page design using the original Heart Sound photographs, About content, public social links, PUNCH! video IDs, and business contact information captured in the site export.

Includes About, three PUNCH! sessions in Watch, Listen Lounge, and Contact. The contact section embeds the existing published HoneyBook form and provides a direct form link as fallback. Inquiry delivery and recipients are managed in HoneyBook. The Listen Lounge links to the original SoundCloud profile and loads its embedded player on demand. Audio tracks from the old Squarespace player were not part of the initial scrape. Exact mix restoration may require access to the old Squarespace media library.

## Local preview

Use Node 22.13 or later and pnpm. Run `pnpm install` and `pnpm dev`. Run `pnpm build` for static output. `next.config.ts` uses `output: 'export'` for a portable site with no application server dependency.

## Before launch

Run `python3 scripts/package-github.py` after the build to prepare browser-uploadable static files and a complete editable source archive. GitHub Pages serves the public bundle from the main branch root; the source archive allows rebuilding without losing the editable React project. Domain registration and business email remain managed separately from website hosting.
