"""Prepare a flat GitHub Pages upload and a complete editable source archive.

Run after pnpm build. The flat public bundle supports browser uploads without
requiring GitHub authentication credentials on the local machine.
"""
from pathlib import Path
import json, shutil, zipfile

root = Path(__file__).resolve().parents[1]
public = root / 'dist/client'
output = root.parent / 'heartsound-github-upload'
output.mkdir(exist_ok=True)
files = [p for p in public.rglob('*') if p.is_file() and '.vite' not in p.parts]
names = [p.name for p in files]
assert len(names) == len(set(names)), 'Flat output filename collision'
prefixes = sorted({p.relative_to(public).parent.as_posix() + '/' for p in files if p.parent != public}, key=len, reverse=True)
for path in files:
    dest = output / path.name
    if path.suffix in {'.html','.css','.js','.json','.rsc'}:
        text = path.read_text()
        for prefix in prefixes:
            text = text.replace('/'+prefix, '/').replace(prefix, '')
        dest.write_text(text)
    else:
        shutil.copy2(path,dest)
with zipfile.ZipFile(output/'website-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for folder in ['app','components','hooks','lib','public','scripts']:
        for path in (root/folder).rglob('*'):
            if path.is_file(): archive.write(path,path.relative_to(root))
    for name in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.json','next.config.ts','vite.config.ts','.gitignore','README.md']:
        archive.write(root/name,name)
print(json.dumps([str(p) for p in sorted(output.iterdir()) if p.is_file()],indent=2))
