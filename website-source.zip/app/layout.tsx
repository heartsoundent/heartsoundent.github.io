import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Heart Sound Entertainment — Music that moves.',description:'Soulful, eclectic DJs and music lovers. Meet Heart Sound Entertainment, watch our PUNCH! sessions, explore the Listen Lounge, and plan your next event.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
